package okay.direct.tck;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import okay.direct.Effect;
import okay.direct.Effects;
import okay.direct.Handler;
import okay.direct.Implicit;
import okay.direct.Resume;
import okay.direct.InPlace;
import okay.direct.Answer;
import okay.direct.std.Throws;
import okay.direct.std.Reader;
import okay.direct.std.State;
import org.junit.jupiter.api.Test;

/**
 * THE TECHNOLOGY COMPATIBILITY KIT: what every implementation of {@link Effects} does. An implementation's test
 * extends it and gives the implementation.
 */
public abstract class EffectsTck implements InterceptorTests, DelimitedTests, EmitTests, RowsTests {
    @Override
    public abstract Effects effects();

    /** Reads a base, counts in state, fails on a negative result: three effects, no monad. */
    static int program(Effect<Reader<Integer>> reader, Effect<State<Integer>> state, Effect<Throws<String>> fail,
            boolean heads) {
        int base = Reader.ask(reader);
        State.put(state, State.get(state) + 1);
        int result = heads ? base : -base;
        return result < 0 ? Throws.raise(fail, "negative: " + result) : result;
    }

    @Test
    void handlersNestInAnyOrder() {
        var fx = effects();
        var heads = Reader.run(fx, 42, reader -> State.run(fx, 0,
            state -> Throws.<String, Integer, RuntimeException>run(fx, fail -> program(reader, state, fail, true))));
        assertEquals(new State.Final<>(1, new Throws.Ok<String, Integer>(42)), heads);

        var tails = Throws.<String, State.Final<Integer, Integer>, RuntimeException>run(fx, fail -> State.run(fx, 0,
            state -> Reader.run(fx, 42, reader -> program(reader, state, fail, false))));
        assertEquals(new Throws.Err<String, State.Final<Integer, Integer>>("negative: -42"), tails);
    }

    @Test
    void theErrorsTypeGivenAsAClassTypesTheBodyWithNoTypedLambda() {
        var fx = effects();
        var ok = Reader.run(fx, 42, reader -> State.run(fx, 0, state ->
            Throws.run(fx, String.class, fail -> program(reader, state, fail, true))));
        assertEquals(new State.Final<>(1, new Throws.Ok<String, Integer>(42)), ok);
        Throws.Result<String, Integer> no = Throws.run(fx, String.class, fail -> Throws.raise(fail, "no"));
        assertEquals(new Throws.Err<String, Integer>("no"), no);
    }

    @Test
    void anOuterOperationPassesTheInnerHandler() {
        var fx = effects();
        var result = Reader.run(fx, 10, reader -> State.run(fx, 1, state -> Reader.ask(reader) + State.get(state)));
        assertEquals(new State.Final<>(1, 11), result);
    }

    @Test
    void operationsInLambdasAndAcrossFunctions() {
        var fx = effects();
        var result = State.run(fx, 0, state -> {
            List.of(1, 2, 3, 4).forEach(x -> State.put(state, State.get(state) + x));
            return List.of(10, 20).stream().map(x -> x + State.get(state)).toList();
        });
        assertEquals(new State.Final<>(10, List.of(20, 30)), result);
    }

    @Test
    void aClauseRunsOutsideTheBodyAndPerformsOuterEffects() {
        var fx = effects();
        // a handler of Throws that counts each failure in an outer state, and resumes nothing
        var result = State.run(fx, 0,
            state -> fx.handle(new Handler<Throws<String>, String, String, RuntimeException>() {
            @Override
            public String ret(String value) {
                return value;
            }

            @Override
            public String on(Throws<String> op, Resume<Throws<String>, String, RuntimeException> k) {
                State.put(state, State.get(state) + 1);
                return switch (op) {
                    case Throws.Raise<String, ?> raise -> "recovered from " + raise.error();
                };
            }
        }, fail -> Throws.<String, String>raise(fail, "boom")));
        assertEquals(new State.Final<>(1, "recovered from boom"), result);
    }

    @Test
    void aGeneralHandlerResumesAndWrapsTheRest() {
        var result = effects().handle(new Handler<Reader<Integer>, Integer, String, RuntimeException>() {
            @Override
            public String ret(Integer value) {
                return "value " + value;
            }

            @Override
            public String on(Reader<Integer> op, Resume<Reader<Integer>, String, RuntimeException> k) {
                return switch (op) {
                    case Reader.Ask<Integer> ask -> "[" + k.resume(ask, 20) + "]";
                };
            }
        }, reader -> Reader.ask(reader) + Reader.ask(reader));
        assertEquals("[[value 40]]", result);
    }

    @Test
    void anAbandonedRestUnwindsAndRunsItsFinallyBlocks() {
        var fx = effects();
        var cleaned = new AtomicBoolean();
        var result = State.run(fx, 0, state -> Throws.<String, Integer, RuntimeException>run(fx, fail -> {
            try {
                return Throws.<String, Integer>raise(fail, "boom");
            } finally {
                cleaned.set(true);
                State.put(state, 7); // an outer effect, still handled while unwinding
            }
        }));
        assertTrue(cleaned.get());
        assertEquals(new State.Final<>(7, new Throws.Err<String, Integer>("boom")), result);
    }

    @Test
    void continuationsAreOneShot() {
        var fx = effects();
        assertThrows(IllegalStateException.class, () -> fx.handle(new Handler<Reader<Boolean>, Boolean, Boolean, RuntimeException>() {
            @Override
            public Boolean ret(Boolean value) {
                return value;
            }

            @Override
            public Boolean on(Reader<Boolean> op, Resume<Reader<Boolean>, Boolean, RuntimeException> k) {
                return switch (op) {
                    case Reader.Ask<Boolean> ask -> k.resume(ask, true) && k.resume(ask, false);
                };
            }
        }, Reader::ask));
    }

    @Test
    void aCapabilityDoesNotOutliveItsHandler() {
        var escaped = new AtomicReference<Effect<Reader<Integer>>>();
        Reader.run(effects(), 1, reader -> {
            escaped.set(reader);
            return 0;
        });
        assertThrows(IllegalStateException.class, () -> Reader.ask(escaped.get()));
    }

    @Test
    void aCapabilityIsConfinedToItsBodysThread() throws InterruptedException {
        var failure = Reader.run(effects(), 1, reader -> {
            var thrown = new AtomicReference<Throwable>();
            var other = Thread.ofPlatform().start(() -> {
                try {
                    Reader.ask(reader);
                } catch (Throwable t) {
                    thrown.set(t);
                }
            });
            other.join(); // InterruptedException: a checked exception of the body, thrown on by run
            return thrown.get();
        });
        assertInstanceOf(IllegalStateException.class, failure);
    }

    @Test
    void aClauseCannotPerformItsOwnEffect() {
        var fx = effects();
        var own = new AtomicReference<Effect<Reader<Integer>>>();
        assertThrows(IllegalStateException.class, () -> fx.handle(new Handler<Reader<Integer>, Integer, Integer, RuntimeException>() {
            @Override
            public Integer ret(Integer value) {
                return value;
            }

            @Override
            public Integer on(Reader<Integer> op, Resume<Reader<Integer>, Integer, RuntimeException> k) {
                return Reader.ask(own.get()); // the clause runs outside the body: its own capability is not usable here
            }
        }, reader -> {
            own.set(reader);
            return Reader.ask(reader);
        }));
    }

    @Test
    void checkedExceptionsOfTheBodyPassThroughHandle() {
        var fx = effects();
        var e = assertThrows(IOException.class, () -> State.run(fx, 0, state -> {
            State.put(state, 1);
            if (State.get(state) == 1) throw new IOException("io");
            return 0;
        }));
        assertEquals("io", e.getMessage());
    }

    @Test
    void uncheckedExceptionsAndErrorsOfTheBodyPropagate() {
        var fx = effects();
        assertEquals("thrown", assertThrows(IllegalArgumentException.class, () -> State.run(fx, 0, state -> {
            State.put(state, 1);
            throw new IllegalArgumentException("thrown");
        })).getMessage());
        assertEquals("error", assertThrows(AssertionError.class, () -> State.run(fx, 0, state -> {
            State.put(state, 1);
            throw new AssertionError("error");
        })).getMessage());
    }

    @Test
    void anInPlaceHandlerRunsInConstantStack() {
        var result = State.run(effects(), 0, state -> {
            for (int i = 0; i < 100_000; i++) State.put(state, State.get(state) + 1);
            return "done";
        });
        assertEquals(new State.Final<>(100_000, "done"), result);
    }

    /** an in-place handler of Reader whose clause does what {@code clause} says */
    static <A> InPlace<Reader<Integer>, A, A> tailReader(java.util.function.BiConsumer<Reader.Ask<Integer>, Answer<Reader<Integer>>> clause) {
        return new InPlace<>() {
            @Override
            public A ret(A value) {
                return value;
            }

            @Override
            public void answer(Reader<Integer> op, Answer<Reader<Integer>> k) {
                switch (op) {
                    case Reader.Ask<Integer> ask -> clause.accept(ask, k);
                }
            }
        };
    }

    @Test
    void anInPlaceHandlersClauseThatThrowsEndsTheBodyAndHandleThrowsIt() {
        var fx = effects();
        var unwound = new AtomicBoolean();
        var thrown = assertThrows(IllegalArgumentException.class, () -> fx.handle(tailReader((ask, k) -> {
            throw new IllegalArgumentException("clause");
        }), (Effect<Reader<Integer>> reader) -> {
            try {
                return Reader.ask(reader);
            } finally {
                unwound.set(true);
            }
        }));
        assertEquals("clause", thrown.getMessage());
        assertTrue(unwound.get());
    }

    @Test
    void anInPlaceHandlersClauseThatDoesNotAnswerEndsTheBody() {
        var fx = effects();
        var unwound = new AtomicBoolean();
        assertThrows(IllegalStateException.class, () -> fx.handle(tailReader((ask, k) -> {}), (Effect<Reader<Integer>> reader) -> {
            try {
                return Reader.ask(reader);
            } finally {
                unwound.set(true);
            }
        }));
        assertTrue(unwound.get());
    }

    @Test
    void anInPlaceHandlersClauseMayPerformAnOuterEffect() {
        var fx = effects();
        var result = State.run(fx, 7, state -> fx.handle(tailReader((ask, k) -> {
            State.put(state, State.get(state) + 1);   // the clause performs the outer State, every ask
            k.answer(ask, State.get(state));
        }), (Effect<Reader<Integer>> reader) -> Reader.ask(reader) + Reader.ask(reader)));
        assertEquals(new State.Final<>(9, 17), result);
    }

    /**
     * A general handler resuming inside an in-place handler's body, 100 000 times, in constant stack: not of every
     * implementation (Espresso's general handler copies the rest at each resumption), so not a test here — an
     * implementation that has it calls this from a test of its own.
     */
    protected void generalHandlerResumingInsideAnInPlaceHandlersBodyInConstantStack() {
        var fx = effects();
        // an interceptor's shape: each ask passed on to the outer state, the rest resumed — a call deeper each time
        var result = State.run(fx, 0, state -> fx.handle(new Handler<Reader<Integer>, Integer, Integer, RuntimeException>() {
            @Override
            public Integer ret(Integer value) {
                return value;
            }

            @Override
            public Integer on(Reader<Integer> op, Resume<Reader<Integer>, Integer, RuntimeException> k) {
                return switch (op) {
                    case Reader.Ask<Integer> ask -> {
                        State.put(state, State.get(state) + 1);
                        yield k.resume(ask, 1);
                    }
                };
            }
        }, reader -> {
            int sum = 0;
            for (int i = 0; i < 100_000; i++) sum += Reader.ask(reader);
            return sum;
        }));
        assertEquals(new State.Final<>(100_000, 100_000), result);
    }

    @Test
    void aProgramRunsInAVirtualThread() throws InterruptedException {
        var fx = effects();
        var out = new AtomicReference<Object>();
        Thread.ofVirtual().start(() -> {
            try {
                out.set(Reader.run(fx, 10, reader -> State.run(fx, 1, state -> {
                    Thread.sleep(5); // parks inside the body
                    return Reader.ask(reader) + State.get(state);
                })));
            } catch (Throwable t) {
                out.set(t);
            }
        }).join();
        assertEquals(new State.Final<>(1, 11), out.get());
    }

    static final Implicit<State<Integer>> COUNTER = Implicit.newInstance();
    static final Implicit<State<Integer>> OTHER = Implicit.newInstance();
    static final Implicit<Reader<Integer>> ENV = Implicit.newInstance();

    /** No capability passed: each found by its key. */
    static int addEnv() {
        State.put(COUNTER.get(), State.get(COUNTER.get()) + Reader.ask(ENV.get()));
        return State.get(COUNTER.get());
    }

    @Test
    void implicitCapabilitiesAreFoundByKeyAcrossFunctions() {
        var fx = effects();
        var result = Reader.run(fx, 5, ENV.in(() -> State.run(fx, 1, COUNTER.in(EffectsTck::addEnv))));
        assertEquals(new State.Final<>(6, 6), result);
    }

    @Test
    void twoKeysOfOneEffectAreTwoCapabilitiesAndAnInnerBindingHidesTheOuter() {
        var fx = effects();
        var result = State.run(fx, 100, COUNTER.in(() -> State.run(fx, 10, OTHER.in(() -> State.run(fx, 1, COUNTER.in(() -> {
            State.put(OTHER.get(), State.get(OTHER.get()) + 1);   // the middle one
            State.put(COUNTER.get(), State.get(COUNTER.get()) + 1); // the inner one: hides the outer
            return State.get(COUNTER.get());
        }))))));
        assertEquals(new State.Final<>(100, new State.Final<>(11, new State.Final<>(2, 2))), result);
    }

    @Test
    void aClauseSeesTheImplicitCapabilitiesOfOutsideItsBody() {
        var fx = effects();
        // the Reader's clause answers with COUNTER: the outer state, not the one bound inside its body
        var result = State.run(fx, 100, COUNTER.in(() -> fx.handle(new Handler<Reader<Integer>, State.Final<Integer, Integer>,
                State.Final<Integer, Integer>, RuntimeException>() {
            @Override
            public State.Final<Integer, Integer> ret(State.Final<Integer, Integer> value) {
                return value;
            }

            @Override
            public State.Final<Integer, Integer> on(Reader<Integer> op,
                    Resume<Reader<Integer>, State.Final<Integer, Integer>, RuntimeException> k) {
                return switch (op) {
                    case Reader.Ask<Integer> ask -> k.resume(ask, State.get(COUNTER.get()));
                };
            }
        }, ENV.in(() -> State.run(fx, 1, COUNTER.in(() -> Reader.ask(ENV.get()) + State.get(COUNTER.get())))))));
        assertEquals(new State.Final<>(100, new State.Final<>(1, 101)), result);
    }

    @Test
    void anImplicitCapabilityIsNotBoundOutsideItsBody() {
        var fx = effects();
        State.run(fx, 0, COUNTER.in(() -> 0));
        assertThrows(IllegalStateException.class, COUNTER::get);
    }
}
